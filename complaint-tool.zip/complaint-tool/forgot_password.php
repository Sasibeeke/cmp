<?php 
    session_start();
    include 'connection.php';
   //echo $_SESSION['error'];die();
?>
<?php include 'header.php';?>
<body>

    
    <!-- login area start -->
    <div class="login-area login-bg">
        <div class="container">
            <div class="login-box ptb--100">
                <form action="forgot_pass.php" method="post">
                    <div class="login-form-head">
                        <h4>Forgot Password</h4>
                        <p>Hey! Forgot Password Your Password ? Reset Now</p><br>
                        <?php
                         //new change added by sasiram 19-07-2023 // 
                          if(isset($_SESSION['errors'])) {
                            $errors = $_SESSION['errors'];
                            // Display the error messages
                            foreach ($errors as $error) {
                                echo "<div class='alert alert-danger' role='alert'>" . $error . '</div>';
                            }
                            // Clear the error messages from the session
                            unset($_SESSION['errors']); 
                        }

                        if(isset($_SESSION['message']))
                        { 
                            echo $_SESSION['message']; 
                            unset($_SESSION['message']);
                        }
                        //new change added by sasiram 19-07-2023 // 
                    ?>
                    </div>
                    <div class="login-form-body">
                        <div class="form-gp">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" name="email" id="exampleInputEmail1" required>
                            <i class="ti-email"></i>
                        </div>
                        <div class="form-gp">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="password" id="exampleInputPassword2" required>
                            <i class="ti-lock"></i>
                            <div class="text-danger"></div>
                        </div>
                        <div class="form-gp">
                            <label for="exampleInputPassword1">Confirm Password</label>
                            <input type="password" name="confirmpassword" id="exampleInputPassword3" required>
                            <i class="ti-lock"></i>
                            <div class="text-danger"></div>
                        </div>
                        <div class="row mb-4 rmber-area">
                            <div class="col-6">
                               
                            </div>
                            <div class="col-6 text-right">
                                <a href="login.php">Try Login from here </a>
                            </div>
                        </div>
                        <div class="submit-btn-area mt-5">
                            <button id="form_submit" type="submit" name="submit">Reset <i class="ti-arrow-right"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- login area end -->

    <?php include 'footer.php';?>
</body>

</html>