

        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="user_incharge.php">
                        <!-- <img src="assets/images/icon/logo.png" alt="logo"> -->
                        <h4 style="color:white;">Dashboard</h4>
                    </a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                                <ul class="collapse">
                                    <li><a href="user_incharge.php">Complaint dashboard</a></li>
                                </ul>
                            </li>
                            <li><a href="pending_complaint_view.php" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Pending Complaints
                                    </span></a>
                               
                            </li>
							<li><a href="completed_complaints.php" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Completed Complaints
                                    </span></a>
                               </li>
                            <li><a href="rejected_complaints.php" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Rejected Complaints
                                    </span></a>
                               </li>   
							 <li><a href="track_complaints_view.php" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Track Complaints
                                    </span></a>
                               </li>  
  
                            
                            <li><a href="logout.php"><i class="ti-share-alt"></i> <span>Logout</span></a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>