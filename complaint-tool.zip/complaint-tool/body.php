
            <!-- header area start -->
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
				
                    <div class="col-sm-7">
					
                        <div class="breadcrumbs-area clearfix">
						<div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                           <h5 class="page-title pull-right text-info" >NIC Pune Complaint Monitoring System</h5>
                        </div>
                    </div>
                    <div class="col-sm-5 clearfix">
                        
						<div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION["username"]; ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                               
                                <a class="dropdown-item" href="logout.php">Log Out</a>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </div>    