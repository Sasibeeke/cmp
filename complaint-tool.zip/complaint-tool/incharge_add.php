<?php

require('connection.php'); 
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {

if(isset($_POST['submit'])){
    //print_r($_POST);die();
    //   echo 'welcomess';die();
	 $section_code = mysqli_real_escape_string($db,($_REQUEST['section_code']));

     if($section_code==='1'){
        $section_name = 'Electrical';
     }elseif($section_code==='2'){
        $section_name = 'Civil';
    }elseif($section_code==='3'){
        $section_name = 'Housekeeping';
     }else{
        $section_name ='Cleaning';
     }

     
     $employee_name = mysqli_real_escape_string($db,($_REQUEST['employee_name']));
     $employee_mobile = mysqli_real_escape_string($db,($_REQUEST['employee_mobile']));
     $employee_designation = mysqli_real_escape_string($db,($_REQUEST['employee_designation']));
    $currentDate = date('Y-m-d');

   // Define the regular expression pattern for a valid mobile number
        $pattern = '/^[0-9]{10}$/';
        if (!preg_match($pattern, $employee_mobile)) {
           $_SESSION['error_message'] = "<div class='alert alert-danger' role='alert'>Please Enter Valid Mobile Number.</div>";
             //redirect is remaining//
             header("location: section_incharge.php");
             exit;
        }

    
      $sql = "INSERT INTO section_incharge_tbl (section_code,section_name,sect_emp_mobile,sect_emp_name,sect_emp_desig,creation_date) VALUES('$section_code','$section_name','$employee_mobile','$employee_name','$employee_designation','$currentDate')";

      
    if(mysqli_query($db, $sql)) {
         $last_id = mysqli_insert_id($db);
            $_SESSION['message'] = "<div class='alert alert-info' role='alert'>Section Incharge Added successfully!</div>";
             //redirect is remaining//
             header("location: view_sectionincharge.php"); 
      }else {
            
             echo "Error: " . $sql . "<br>" . mysqli_error($db);
           }
      
}

}else{

	echo 'invalid request method';
}



?>