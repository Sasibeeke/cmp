<?php 

session_start();
include 'connection.php';

if(!isset($_SESSION["username"])){
header("Location: login.php");
}


?>
<?php include 'header.php';?>

<body>
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<!-- page container area start -->
<div class="page-container">
<?php include 'sidebar.php';?>
<!-- main content area start -->
<div class="main-content">

<!-- header area start -->
<?php include 'body.php';?>
<!-- header area end -->

<div class="main-content-inner">
    <div class="row">
        <div class="col-lg-6 col-ml-12">
            <div class="row">
                <!-- Textual inputs start -->
                <div class="col-12 mt-5">
                    <div class="card">
                        <div class="card-body">
						<h4 class="header-title">User Form</h4>
						<?php
						 //new change added by sasiram 19-07-2023 // 
                          if(isset($_SESSION['errors'])) {
                            $errors = $_SESSION['errors'];

                            // Display the error messages
                            foreach ($errors as $error) {
                                echo "<div class='alert alert-danger' role='alert'>" . $error . '</div>';
                            }

                            // Clear the error messages from the session
                            unset($_SESSION['errors']);	
                        }
                        //new change added by sasiram 19-07-2023 // 
                            ?>
                        <form class="needs-validation" novalidate="" action="register_user.php" method="POST" >
							 
                            <div class="form-group">
                                <label for="validationCustom02" class="col-form-label">Full Name</label>
                                <input class="form-control" type="text" name="name" value="" id="validationCustom02" placeholder="Enter Full Name" required="">
								<div class="invalid-feedback">
                                    Please Enter Your Full Name
                                </div>
                            </div>
							<div class="form-group">
                                <label for="validationCustom03" class="col-form-label">Email address</label>
                                <input class="form-control" type="email" value="" name="email" id="validationCustom03" placeholder="Enter Email address" required="">
								<div class="invalid-feedback">
                                    Please Enter Your email id
                                </div>
                            </div>
                            <div class="form-group">
                            <label for="" class="col-form-label">Enter Employee Mobile</label>
                            <input class="form-control" type="text" value="" name="employee_mobile" id="" placeholder="Enter Mobile No" onkeypress="return validateNumber(event)"  maxlength="10" minlength="10" required>
                            <div class="invalid-feedback">
                                    Please Enter Your Valid Mobile Number
                                </div>
                            </div>
							<div class="form-group">
                                <label for="validationCustom04" class="col-form-label">Password</label>
                                <input class="form-control" type="password" value="" name="password" id="validationCustom04" placeholder="Enter Your Password" required="">
								<div class="invalid-feedback">
                                    Please Enter Your Password
                                </div>
                            </div>
							<div class="form-group">
                                <label for="validationCustom05" class="col-form-label">Confirm Password</label>
                                <input class="form-control" type="password" value="" name="confirmpassword" id="validationCustom05" placeholder="Enter Confirm Password" required="">
								<div class="invalid-feedback">
                                    Please Enter Your Confirm Password
                                </div>
							</div>

                        <div class="form-group">
                            <label for="validationCustom01" class="col-form-label">Select User Type</label>
                            <select class="form-control" name="role" id="validationCustom01" style="font-size: 14px;padding:3.72px 15.8px;" onchange="loaddiv(this.value)" required="">
                             <option value=''> Select User Type </option>
                             <option value="1">Floor Coordinator</option>
                             <option value="2">Section Incharge</option>
                            </select>
                            <div class="invalid-feedback">
                             Please Select User Type
                            </div>
                        </div>

                        <div class="form-group" id="floor" style="display:none">
                            <label for="" class="col-form-label">Select Floor</label>
                            <select class="form-control" name="floor_no" id="floor_no" style="font-size: 14px;padding:3.72px 15.8px;" >
                                <option value="">Select Floor</option>
                                <option value="0">Ground</option>
                                <option value="1">First</option>
                                <option value="2">Second</option>
                                <option value="3">Third</option>
                                <option value="4">Fourth</option>
                            </select>
                          </div>

                          <div class="form-group" id="incharge" style="display:none">
                             <label for="" class="col-form-label">Select Section Incharge</label>
                            <?php
                            $sql = "SELECT section_code, section_name FROM section_tbl";
                            //echo $query;die(); 
                            $result = mysqli_query($db,$sql);
                            if($result){
                                        

                        echo '<select class="form-control" style="padding:7px !important;font-size:13px;" name="section_code" id="section_code">';
                        echo '<option value="">Select Section</option>';
                        while ($row = mysqli_fetch_assoc($result)) {
                            $section_code = $row['section_code'];
                            $section_name = $row['section_name'];

                            echo '<option value="' . $section_code . '">' . $section_name . '</option>';
                        }
                        echo '</select>';
                        }
                    ?>
                        </div>

                        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                        </form>    
                        </div>
                    </div>
                </div>
                <!-- Textual inputs end -->
            </div>
        </div>
        <div class="col-lg-6 col-ml-12">
            <div class="row">
                 <!-- Server side start -->
                <div class="col-12">
                    <div class="card mt-5">
                        <div class="card-body">
                            <h4 class="header-title">Instructions :- </h4>
							1. Enter Full Name.<br/>
                            2. Enter Your Mobile Number.<br/> 
							3. Enter Your Email Address.<br/> 
							4. Enter Your Password.<br/> 
							5. Please Select User Type.<br/> 
							6. Please Select Your Floor .<br/>
                            7. Please Select Your Section Incharge .<br/> 
                            8. Please Review form before submission .<br/> 
                        </div>
                    </div>
                </div>
                <!-- Server side end -->
            </div>
        </div>
    </div>
</div>
</div>
<!-- main content area end -->
<!-- footer area start-->
<?php include 'footer_bar.php';?>
<!-- footer area end-->
</div>
<!-- page container area end -->
<?php include 'footer.php';?>
<script>
function loaddiv(id)
 {
     if(id=='1')
     {
        
        $("#floor").show();
        $("#incharge").hide(); 
        document.getElementById("section_code").value= '';
     }
     else if(id=='2')
     {
         $("#incharge").show(); 
          $("#floor").hide();
          document.getElementById("floor_no").value='';
     }
    
 }

 function validateNumber(e) {
            const pattern = /^[0-9]$/;

            return pattern.test(e.key )
        }
</script>
</body>

</html>
