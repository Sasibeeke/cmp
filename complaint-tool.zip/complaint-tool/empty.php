

<?php include 'header.php';?>

<body>

    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
       
           <?php include 'sidenav.php';?>
            
            <!-- main content area start -->
            <div class="main-content">
            <?php include 'body.php';?>

              <h1>welcome to html</h1>
            </div>
            <!-- main content area end -->
     </div>
    <!-- page container area end -->
   
  <?php include 'body_head.php';?> 

<?php include 'footer_bar.php';?>
<?php include 'footer.php';?>

</body>

</html>
