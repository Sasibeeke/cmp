 <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2023. All right reserved<a href="#"> NIC Bas Team</a>.</p>
            </div>
        </footer>
        <!-- footer area end-->