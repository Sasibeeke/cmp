<?php 

session_start();
include 'connection.php';

if(!isset($_SESSION["username"])){
header("Location: login.php");
}

?>
<?php include 'header.php';?>


<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
   
    <!-- page container area start -->
    <div class="page-container">
	  <?php include 'sidebar.php';?>
        <!-- main content area start -->
        <div class="main-content">
			<!-- header area start -->
            <?php include 'body.php';?>
            <!-- header area end -->
          
            <div class="main-content-inner">
                <div class="row">
                    <!-- data table start -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
							<?php
                                        if(isset($_SESSION['error']))
                                        { 
                                            echo $_SESSION['error']; 
                                            unset($_SESSION['error']);
                                        }?>
							<div style="float:right">
								<a class="btn btn-success mb-3" href="user_form.php" role="button">Add User</a>
							</div>
						
                                <h4 class="header-title">View Users</h4>
                                <div class="data-tables">
								 <table id="dataTable" class="table table-striped table-bordered" style="width:100%">
                                     	
                                        <thead class="bg-light text-capitalize">
                                            <tr>
												<th>S.No</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>Registered Date</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
										$sno=1;
										$sql = "select * from user";
										$user_data = mysqli_query($db, $sql);  
										
										if ($user_data->num_rows > 0) {
										  // output data of each row
										while($row = mysqli_fetch_assoc($user_data)) {
											Print "<tr><td>".$sno."</td>";
											Print "<td>".$row["name"]."</td>";
                                            Print "<td>".$row["mobile"]."</td>";
											Print "<td>".$row["email"]."</td>";
											Print "<td>".$row["creation_date"]."</td>";
											$sno++;
										}
										} else {
										  Print "<tr><td> No Records Found</td></tr>";
										}
																		
										?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- data table end -->
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <?php include 'footer_bar.php';?>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- jquery latest version -->
    <?php include 'footer.php';?>
</body>

</html>
