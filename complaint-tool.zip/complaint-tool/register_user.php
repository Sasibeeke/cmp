<?php
require('connection.php'); 
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {

if(isset($_POST['submit'])){
    $name = mysqli_real_escape_string($db,($_REQUEST['name']));
	$email = mysqli_real_escape_string($db,($_REQUEST['email']));
    $employee_mobile = mysqli_real_escape_string($db,($_REQUEST['employee_mobile']));
    $password = mysqli_real_escape_string($db,($_REQUEST['password'])); 
    $confirmpassword = mysqli_real_escape_string($db,($_REQUEST['confirmpassword']));
	$role = mysqli_real_escape_string($db,($_REQUEST['role']));
	$floor_no = mysqli_real_escape_string($db,($_REQUEST['floor_no']));
	$section_code = mysqli_real_escape_string($db,($_REQUEST['section_code']));	

    //new change added by sasiram 19-07-2023 // 
        $errors=[];
        if(empty($name)) {
            $errors[] = 'Name Field is required.';
         }
         if(empty($email)) {
            $errors[] = 'Email is required.';
         } 
        if(empty($password)) {
            $errors[] = 'Password is required.';
         }
        if(empty($confirmpassword)) {
            $errors[] = 'Confirm Password is required.';
         }
        $email_query = "select email from user where email ='$email'";  
        $email_data= mysqli_query($db, $email_query);
        if($email_data->num_rows > 0) {
             // $errors[] = "<div class='alert alert-danger' role='alert'>Email Already Exists!</div>";
             $errors[] = "Email Already Exists!";
          }
        if($password !== $confirmpassword) {
            $errors[] = 'Confirm Password does not match the password Field.';
        }
        if(strlen($password) < 8 || !preg_match('/[A-Z]/', $password)) {
               $errors[] = "Password must be at least 8 characters long and contain at least one uppercase letter!";
            }
         if(empty($role)) {
            $errors[] = 'User Type is required.';
         }
        if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: user_form.php');
        exit;
        } 

//new change added by sasiram 19-07-2023 // 
       

	



      // Performing insert query execution
        // here our table name is register
    $sql = "INSERT INTO user (name,mobile,email,password,role,creation_date,floor_no,section_code) VALUES ('$name','$employee_mobile','$email','$password','$role',now(),'$floor_no','$section_code')";
        
       // $result = mysqli_query($db, $sql);

      //echo mysqli_insert_id($db);
      //echo $sql;
     // die();
   
   
    
    
    if (mysqli_query($db, $sql)) {
         // session_register("myusername");
             $last_id = mysqli_insert_id($db);
           //  echo "New record created successfully. Last inserted ID is: " . $last_id;
             //new change added by sasiram 19-07-2023 // 
             unset($_SESSION['errors']);
             //new change added by sasiram 19-07-2023 // 
             $_SESSION['error'] = "<div class='alert alert-info alert-dismissible fade show' role='alert'>User Registered successfully!
             </div>";
             header("location: view_user.php"); 
      }else {
            
             echo "Error: " . $sql . "<br>" . mysqli_error($db);
		     }
      }
}
   else{

	echo 'invalid request method';
}



?>