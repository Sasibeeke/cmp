<?php 
session_start();
require('connection.php'); 

if(isset($_POST['submit'])){
        $email = mysqli_real_escape_string($db,($_REQUEST['email']));      
        $password = mysqli_real_escape_string($db,($_REQUEST['password']));
        $confirmpassword = mysqli_real_escape_string($db,($_REQUEST['confirmpassword'])); 
        $errors=[]; 
          if(empty($email)) {
            $errors[] = 'Email id is required.';
         }else{
            $email_query = "select email from user where email ='$email'";  
            $email_data= mysqli_query($db, $email_query);
            if($email_data->num_rows=='0') {
                 // $errors[] = "<div class='alert alert-danger' role='alert'>Email Already Exists!</div>";
                 $errors[] = "Your Email id is not register with us please register first!";
              }
         }   
         if(empty($password)) {
            $errors[] = 'Password filed is required.';
         }
        if(empty($confirmpassword)) {
            $errors[] = 'Confirm Password is required.';
         }
        if($password !== $confirmpassword) {
            $errors[] = 'Confirm Password does not match with the password Field.';
        }

        if(strlen($password) < 8 || !preg_match('/[A-Z]/', $password)) {
               $errors[] = "Password must be at least 8 characters long and contain at least one uppercase letter!";
            }

        if(!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: forgot_password.php');
        exit;
        }
        $sql = "update user set password='$password' where email ='$email'";
        $result = mysqli_query($db,$sql);
        if(mysqli_affected_rows($db)>0){
            $_SESSION['message'] = "<div class='alert alert-success alert-dismissible fade show' role='alert'>Your Password Updated Successfully!Please try to login!</div>"; 
                header("location: forgot_password.php");
         }else{
            $_SESSION['message'] = "<div class='alert alert-danger' role='alert'>Due to some issue your password not updated,Please try after some time!</div>"; 
                header("location: forgot_password.php");
         }


          

}


?>